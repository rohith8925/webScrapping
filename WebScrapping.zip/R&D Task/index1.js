const express = require("express");
const axios = require("axios");
const cheerio = require("cheerio");
const createCsvWriter = require("csv-writer").createObjectCsvWriter;

const app = express();
const port = 3000; 

app.get("/scrappingURL", async (req, res) => {
  try {
    // Fetch the HTML content of the webpage
    const response = await axios.get(
      "https://www.centralbank.ae/en/forex-eibor/exchange-rates/"
    );

    // Load the HTML content into cheerio
    const $ = cheerio.load(response.data);

    // Select the table rows and extract the data
    const tableData = [];
    $("table tbody tr").each((index, row) => {
      const columns = $(row).find("td");
      const Currency = columns.eq(1).text().trim();
      const Rates = columns.eq(2).text().trim();
      tableData.push({ Currency, Rates });
    });

    // Create and write to the CSV file
    const csvWriter = createCsvWriter({
      path: "outputfile.csv",
      header: [
        {
          id: "Currency",
          title: "currency",
        },
        {
          id: "Rates",
          title: "Exchange Rate",
        },
      ],
    });
    await csvWriter.writeRecords(tableData);

    res
      .status(200)
      .json({ message: "Data retrieved from URL and exported to CSV" });
  } catch (error) {
    console.error(error);
    res
      .status(500)
      .json({ error: "An error occurred while scraping the data." });
  }
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
