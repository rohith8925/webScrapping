const express = require("express");
const puppeteer = require("puppeteer");
const createCsvWriter = require("csv-writer").createObjectCsvWriter;
const bodyParser = require("body-parser");

const app = express();
const port = 3000;

app.use(bodyParser.json());

app.get("/scrappingAPI", async (req, res) => {
  try {
    console.log(req.body);
    const url = req.body.url;

    if (!url) {
      return res
        .status(400)
        .json({ error: "🤷‍♂️ URL is required in the request body" });
    }

    const browser = await puppeteer.launch();
    const page = await browser.newPage();

    await page.goto(url);

    await page.waitForSelector(
      "table"
    );

    const tableData = await page.evaluate(() => {
      const data = [];
      const rows = document.querySelectorAll(
        "table tbody tr"
      );

      rows.forEach((row) => {
        const columns = row.querySelectorAll("td");
        const Currency = columns[1].textContent.trim();
        const Rates = columns[2].textContent.trim();
        data.push({ Currency, Rates });
      });

      return data;
    });

    // Create and write to the CSV file
    const csvWriter = createCsvWriter({
      path: "outputfile.csv",
      header: [
        { id: "Currency", title: "currency" },
        { id: "Rates", title: "Exchange Rate" },
      ],
    });

    await csvWriter.writeRecords(tableData);

    console.log("✅ Data retrieved from URL and exported to CSV");

    res
      .status(200)
      .json({ message: "✅ Data retrieved from URL and exported to CSV" });
  } catch (error) {
    console.error("An error occurred:", error);
    res
      .status(500)
      .json({ error: "🚫 An error occurred while scraping the data." });
  } finally {
    await browser.close();
  }
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
